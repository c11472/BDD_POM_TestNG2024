package Geeksforgeeks_July24_BDDPOM_Framework_Day14.Geeksforgeeks_July24_BDDPOM_Framework_Day14;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
