package com.pages.jpetstore;

import org.openqa.selenium.WebDriver;

public class google1 {
	WebDriver wd;
	
	public void init_google(WebDriver wd) {
		this.wd=wd;
		
	}
	public void LaunchGoogle() {
		wd.get("https://www.google.com");
	}
}
