package com.pages.jpetstore;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.google.common.io.Files;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class jpet_page1 {
	
	WebDriver wd;
	
	// Locators
	
	By  ETS = By.xpath("//*[contains(text(),'Enter the Store')]");
	By  textc1=By.xpath("//*[contains(text(),'Welcome to JPetStore 6')]");
	
	By  signinlink = By.xpath("//*[contains(text(),'Sign In')]");
	By  unm = By.xpath("//*[@name='username']");
	By  pwd = By.xpath("//*[@name='password']");
	public void init_pag1(WebDriver wd) {
		this.wd=wd;
	}
	
	
	public void Launch_Jpet_App() throws IOException {
		wd.get("https://petstore.octoperf.com/");
		
		  File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
	  	  Files.copy(src, new File("./Screenshots/shot1.png"));		

	}
	
	public void Click_On_EnterToStore() {
		wd.findElement(ETS).click();
	}
	public void clicksinlink() throws InterruptedException {
		Thread.sleep(3000);
		wd.findElement(signinlink).click();
	}
	public void enterunm(String username,String password) {
		wd.findElement(unm).sendKeys(username);
		wd.findElement(pwd).sendKeys(password);
		
	}
	
	
}
