package com.stepsdefinitions.jpetstore;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.jpetstore.jpet_page1;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepdef_jpet_page1feature {
	 WebDriver wd = new FirefoxDriver();
	 ExtentReports ext1; // class 
	 ExtentTest test;//interface 

	 //page object space
	 jpet_page1 page1obj = new jpet_page1();

	 @Before
		public void extentTestDemo() {
			ExtentHtmlReporter report = new ExtentHtmlReporter ("./HTMLReport/testreport.html");
			ext1=new ExtentReports(); // ExtentReports Class
			ext1.attachReporter(report); // attaching to ext1 --- extentReport
			test = ext1.createTest("user.dir", "test");

			
		}
		

     	 
	 @Given("The user is in home page of jpet app")
	 public void launch_browser() throws IOException {
		 page1obj.init_pag1(wd);//initp1
		 page1obj.Launch_Jpet_App(); //step1
		 test.log(Status.PASS, "The init for step-1 page1");
		 //validation
		 //page1obj.Click_On_EnterToStore();
		 
		 
	 }
	 @When("The user clicks on enter the store")
	 public void Click_Enter_The_Store() {
		 page1obj.Click_On_EnterToStore(); //step-2 method
		 System.out.println("This goes to different page");
		 
	 }
	 @When("The user shoule able to access the store page")
	 public void access_store_page() {
		 System.out.println("This goes to different page");//call the method
		 	 
	 }
	 
	 @When("The user clicks on signin link")
	 public void clickonsignin() throws InterruptedException {
		 page1obj.clicksinlink();
	 }

	 
	 @When("^The user enters the (.*) and (.*)$")
		 public void performlogin(String unm,String pwd) {
		
		 page1obj.enterunm(unm, pwd);
		 
		 }
	 
	 @After
	 public void test1() {
		 ext1.close();
		 ext1.flush();
	 }
		 
	 }
	 
	
	 

