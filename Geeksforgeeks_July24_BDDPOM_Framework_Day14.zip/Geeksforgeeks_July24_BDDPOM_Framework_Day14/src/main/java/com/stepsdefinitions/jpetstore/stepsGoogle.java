package com.stepsdefinitions.jpetstore;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.jpetstore.google1;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepsGoogle {
	
	google1 g1=new google1();
	WebDriver wd;
	
	   @Given("The user should be in gogle homepage")
	   public void launchapp() {
		   wd = new ChromeDriver();
		   g1.init_google(wd);
		   g1.LaunchGoogle();
		   

		   
		   
	   }
	   


}
